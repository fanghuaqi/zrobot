/*
 * =====================================================================================
 *
 *       Filename:  led_demo.c
 *
 *    Description:  CGI source for led demo	
 *
 *        Version:  1.0
 *        Created:  08/01/2012 01:56:33 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */
//#include <stdlib.h>
#include <stdio.h>
int main ()
{

	printf("Content-type: text/html\n\n");
	printf("<html>\n");
	printf("<head>\n");
	printf("<title> Hello World from C-CGI!</title>\n");
	printf("</head>\n");
	printf("</html>\n");
	return 0;
}
