#!/bin/sh
echo //////////////////////////////////////////////////
echo ///                                            ///
echo ///  XILINX Web-server-Demo Based on ZedBoard  ///
echo ///                                            ///
echo //////////////////////////////////////////////////
/root/boa/boa &
